import React from 'react';

import {
  ScrollView,
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

import { 
  NavigationContainer,
  styled,
} from 'styled-components/native';

// Exemple de données de recettes
const recipes = [
  {
    id: '1',
    title: 'Couscous Marocain',
    image:
      'https://cdn.goody.buzz/media/20190101173734/coucous-marocain-800x600.jpg',
  },
  {
    id: '2',
    title: 'Pancakes',
    image:
      'https://www.allrecipes.com/thmb/WqWggh6NwG-r8PoeA3OfW908FUY=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/21014-Good-old-Fashioned-Pancakes-mfs_001-1fa26bcdedc345f182537d95b6cf92d8.jpg',
  },
  {
    id: '3',
    title: 'Bao',
    image:
      'https://breadtopia.com/wp-content/uploads/2022/09/20220831_132221-800x600.jpg',
  },
  {
    id: '4',
    title: 'Poulet Basquaise',
    image:
      'https://assets.afcdn.com/recipe/20161116/7224_w1024h768c1cx1972cy3850cxt0cyt0cxb3840cyb5760.jpg',
  },
  {
    id: '5',
    title: 'Poulet Basquaise',
    image:
      'https://assets.afcdn.com/recipe/20161116/7224_w1024h768c1cx1972cy3850cxt0cyt0cxb3840cyb5760.jpg',
  },
  {
    id: '6',
    title: 'Couscous Marocain',
    image:
      'https://cdn.goody.buzz/media/20190101173734/coucous-marocain-800x600.jpg',
  },
  {
    id: '7',
    title: 'Pancakes',
    image:
      'https://www.allrecipes.com/thmb/WqWggh6NwG-r8PoeA3OfW908FUY=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/21014-Good-old-Fashioned-Pancakes-mfs_001-1fa26bcdedc345f182537d95b6cf92d8.jpg',
  },
  {
    id: '8',
    title: 'Bao',
    image:
      'https://breadtopia.com/wp-content/uploads/2022/09/20220831_132221-800x600.jpg',
  },
  {
    id: '9',
    title: 'Poulet Basquaise',
    image:
      'https://assets.afcdn.com/recipe/20161116/7224_w1024h768c1cx1972cy3850cxt0cyt0cxb3840cyb5760.jpg',
  },
  {
    id: '10',
    title: 'Poulet Basquaise',
    image:
      'https://assets.afcdn.com/recipe/20161116/7224_w1024h768c1cx1972cy3850cxt0cyt0cxb3840cyb5760.jpg',
  },
  // Ajoutez plus de recettes ici
];

// Composant Card
const Card = ({recipe, onPress}) => (
  <CardContainer>
    <TouchableOpacity onPress={() => onPress(recipe)} style={styles.Opacity}>
      <View>
        <RecipeImage source={{uri: recipe.image}} />
        <RecipeTitle>{recipe.title}</RecipeTitle>
      </View>
    </TouchableOpacity>
  </CardContainer>
);

// Composant principal
const HomeScreen = () => {
  const handleCardPress = (recipe) => {
    alert(`Vous avez cliqué sur ${recipe.title}`);
    // Vous pouvez remplacer cette alerte par une navigation ou toute autre action
  };

  const renderCardsInRows = () => {
    const rows = [];
    for (let i = 0; i < recipes.length; i += 2) {
      rows.push(
        <Row key={i}>
          <Card recipe={recipes[i]} onPress={handleCardPress} />
          {recipes[i + 1] ? (
            <Card recipe={recipes[i + 1]} onPress={handleCardPress} />
          ) : (
            <Placeholder />
          )}
        </Row>
      );
    }
    return rows;
  };

  return (
    <Container>
      <ScrollView contentContainerStyle={{padding: 10}}>
        {renderCardsInRows()}
      </ScrollView>
    </Container>
  );
};



export default HomeScreen;

// Styles
const Container = styled.View`
  flex: 1;
  background-color: #f8f8f8;
`;

const Row = styled.View`
  flex-direction: row;
  justify-content: space-between;
`;

const CardContainer = styled.View`
  background-color: #fff;
  border-radius: 10px;
  overflow: hidden;
  margin: 10px;
  flex: 1;
  /* Styles pour les ombres */
  shadow-color: #000;
  shadow-offset: 0px 2px;
  shadow-opacity: 0.3;
  shadow-radius: 4px;
  elevation: 5;
`;

const RecipeImage = styled.Image`
  width: 100%;
  height: 150px;
`;

const RecipeTitle = styled.Text`
  padding: 10px;
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  color: #333;
`;

const Placeholder = styled.View`
  flex: 1;
  margin: 10px;
`;

const styles = StyleSheet.create({
  Opacity: {},
});
