
import HomeScreen from './HomeScreen.js';
import DetailsScreen from './DetailsScreen.js';

import { 
  NavigationContainer,
  styled,
} from 'styled-components/native';

import {
  createStackNavigator,
} from '@react-navigation/stack';

function afficheHome() {
  return (
    <HomeScreen />
  );
}

function afficheDetails() {
  return (
    <DetailsScreen />    
  );
}

const Stack = createStackNavigator();

const Main = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={afficheHome} options={{title: 'Recettes'}} />
        <Stack.Screen name="Details" component={afficheDetails} options={{title: 'Détails de la recette'}} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default Main;