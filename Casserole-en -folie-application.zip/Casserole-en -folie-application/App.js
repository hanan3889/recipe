
import Navigation from './components/Navigation.js';


const Main = () => {
  return (
    <Navigation />
  );
};

export default Main;