import {
  Text,
} from 'react-native';

import { 
  styled,
} from 'styled-components/native';

const DetailsScreen = ({route}) => {
  const {recipe} = route.params;
  return (
    <Container>
      <RecipeImage source={{uri: recipe.image}} style={{height: 300}} />
      <RecipeTitle>{recipe.title}</RecipeTitle>
      <Text>{recipe.description || "Aucune description disponible."}</Text>
    </Container>
  );
};

const RecipeImage = styled.Image`
  width: 100%;
  height: 150px;
`;

const RecipeTitle = styled.Text`
  padding: 10px;
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  color: #333;
`;

// Styles
const Container = styled.View`
  flex: 1;
  background-color: #f8f8f8;
`;

export default DetailsScreen;